Copy services to the services folder. When you open a project which has a .sql
file in it, you will need to import it into your database before running 
the example. Also set dbconfig.php in the services folder to match your installation.