<?php
/**
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING,
 * BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @copyright (c) 2003 amfphp.org
 * @package flashservices
 * @subpackage util
 */
/**
 * The DescribeService is used to provide a description of the class
 * to the service browser
 *
 * This file was adapted from the old RemotingService which was a pretty
 * nasty idea all along
 * 
 * @package flashservices
 * @subpackage util
 * @version $Id: DescribeService.php,v 1.1 2005/04/02 18:41:49 pmineault Exp $
 */
class DescribeService
{
    function DescribeService()
    {
    	
    }

	/**
	 * Describes the service
	 */
    function describe(&$service, $name)
    {
        $description = array();
        $description["version"] = "1.0";
        $description["address"] = $name;
        $description["functions"] = array();

        foreach ($service->methodTable as $key => $value) {
            if ($value["access"] = "remote")    {
            	$args = array();
            	if(is_array($value["arguments"]) && count($value["arguments"]) >= 1)
            	{
	            	foreach($value["arguments"] as $key2 => $arg)
	            	{
	            		if(is_array($arg))
	            		{
                        $args[] = array("name" => $key2,
	            				  "required" => $arg['required'] ? 'true' : 'false',
	            				  "type" => $arg['type'],
	            				  "description" => $arg['description']
	            				  );
	            		}
	            		else
	            		{
                        $args[] = array("name" => $arg,
	            				  "required" => "true",
	            				  "type" => "undefined");
	            		}
	            	}
            	}
            	
            	if( !isset( $value["returns"] ) )
            	{
            		$returns = 'undefined';
            	}
            	else
            	{
            		$returns = $value["returns"];
            	}
            	
                $description["functions"][] = array(
                    "description" => $value["description"],
                    "name" => $key,
                    "version" => "1.0",
                    "returns" => $returns,
                    "arguments" => $args
                );
            }
        }
        return $description;
    }
}

?>